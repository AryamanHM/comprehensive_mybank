# Comprehensive Exam Question Banks (VIT)

* Compilation of all question banks for Vellore Institute of Technology.
* Crowd sourced from various collaborators.
* Please suggest edits.

## Branches Available
```
BBT
BCB
BCE
BCI
BCL
BCM
BEC
BEE
BEI
BIS
BIT
BMD
BME
BPI
```

## Disclaimer

* For educational purposes only.
* E-mail [kapsjacob@gmail.com](mailto:kapsjacob@gmail.com) for adding more question banks.
* jacob5412/comprehensive-VIT is licensed under the Creative Commons Zero v1.0 Universal
