# mark
attendance app for marking students present/absent. Authentication using NFC and Fingerprint  
